export interface Contact {


    _id?: string
    fullname: string,
    email: string,
    phone: string,
    imgUrl: string
}

    // setId?() {
    //     var text = "";
    //     var possible = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";

    //     for (var i = 0; i < 4; i++) {
    //         text += possible.charAt(Math.floor(Math.random() * possible.length));
    //     }
    //     this._id = text;
    // }

