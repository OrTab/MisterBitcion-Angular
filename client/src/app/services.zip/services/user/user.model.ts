export interface User {
    _id:string
    username: string,
    fullname:string
    coins: number
    moves: Array<any>,
    phone: string,
    email: string,
    imgUrl:string,
}
